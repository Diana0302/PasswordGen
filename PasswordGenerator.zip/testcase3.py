
string3 = 'candyland'

