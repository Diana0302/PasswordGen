import random
import string

    
def my_symbols_function(num_output):
    #a function that will ensure a symbols is added in the passcode
    #generated for the user
        my_input = num_output
        sym_output = ''
        #generator a random symbol
        sym_dict = {0:'!', 1:'@', 2:'#', 3:'$', 4:'&', 5:'*', 6:'~', 7:'+', 8:'^', 9:'%'}
        random_key_generator = random.randint(0,9)
        random_sym = sym_dict[random_key_generator]
        #print(random_sym)
        
        for val in my_input:
            if ord(val) >= 97:
                my_input = list(my_input)
                my_input[my_input.index(val)] = random_sym
                sym_output = "".join(my_input) 
            else:
                sym_output = my_input + '@'
            return 'Thank you for using Security System Passcode Generator\n Passcode : ' + sym_output
            


def my_numbers_function(up_output):
    """a function that will ensure numbers are included in passcode to provide a more 
       secure passcode to user"""
    
    my_input = up_output
    num_output = ''
   
   #ran_key will be the random number that will be substituting in a random
   #index of the passcode
    
    ran_key = str(random.randint(random.randint(0,4), random.randint(5,9)))
    #print(type(ran_key))
    #print(ran_key)
    
   #ran_index
    mylist = [1,3,5,7,2,4,6,0]
    ran_index = random.randint(0, len(mylist))
    #print(ran_index)

    for char in my_input:
        #string0 = print('numbers that will be compared', str(my_input.index(char)) , str(ran_index))
        if (my_input.index(char)) == ran_index:
            char = ran_key
            my_input = list(my_input)
            my_input[ran_index] = char
            num_output = "".join(my_input)      
        else:
            char = str(random.randint(0,9))
            my_input = list(my_input)
            my_input[random.randint(0,7)] = char
            num_output = "".join(my_input)      
            
        return my_symbols_function(num_output)

def hashing(user_string):
    """a function that will make any vowel into an uppercase letter
        each vowel will corespond to a key and will have a value """
    my_input = user_string
    up_output = ''
    my_vowels_dictionary = {'a':'A', 'e':'L','i':'I','o':'D','u':'N','A':'Z', 'E':'E','I':'H','O':'R','U':'S'}

    for val in user_string:
        if val in my_vowels_dictionary:
            up_output = up_output + my_vowels_dictionary[val]
        else:
            up_output = up_output + val
    return my_numbers_function(up_output)


  
   
                      
        
    
#testing my module
#diana_string = 'haveaniceday'
#diana_new_string = print(hashing(diana_string)) 

#tubby_string = 'themoreyouknow'
#tubby_new_string = print(hashing(tubby_string))
        
        

    
    
    
        

            